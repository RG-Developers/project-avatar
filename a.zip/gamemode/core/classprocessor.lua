if CLIENT then
    ready = false
    hook.Add( "Think", "AbilThink", function()
        if LocalPlayer():Team() == 3 or 5 then
            subclass = GetSubClass(LocalPlayer())
            isdown = input.IsKeyDown( KEY_Q )
            if (isdown == true) and (ready == true) then
                net.Start("abilityUse")
                net.SendToServer()
                ready = false
            end
        end
    end)

    net.Receive("abilityReady", function()
        ready = true
    end)
end
if SERVER then
    hook.Add( "Think", "newguy_boost", function()
        for _,plyt in player:GetAll() do
            if plyt:Team() == 3 or 5 then
                subclass = GetSubClass(v)
                if subclass == 3 then
                    local plys = ents.FindInSphere(plyt:GetPos(),600)
                    for _,v in pairs(plys) do
                        if v:IsPlayer() then
                            v:SetTeam(5)
                        end
                    end
                end
            end
        end
    end)
    starttime = CurTime() + 1
    bugcreatetime = starttime + 1
    bugparsers = {}
    bugs = {}
    bugssounds = {}
    bugcount = 0
    nextplay = 0
    function getBugs()
        return bugs 
    end

    function indexOf(array, value)
        for i, v in ipairs(array) do
            if v == value then
                return i
            end
        end
        return nil
    end

    function collectBug(entity)
        if bugs[entity] then
            SetGlobalInt("TestersScore", GetGlobalInt("TestersScore") + math.floor(bugs[entity]['score']))
            SetGlobalInt("ScientistsScore", GetGlobalInt("ScientistsScore") -  math.floor(bugs[entity]['score']))
            CreateSound(entity, "/project_avatar/bugs/playerpickupbug_"..math.random(1,3)..".wav"):Play()
            removeBug(entity)
            print(GetGlobalInt("TestersScore"))
            return true
        end
    end

    function removeBug(bug)
        CreateSound(bug, "/project_avatar/bugs/bugfix_"..math.random(1,2)..".wav"):Play()
        bugs[bug]['leak']:Remove()
        bugs[bug]['bug']:Remove()
        --bugssounds[bug]:Stop()
        bugs[bug] = "collected"
        bug:Remove()
        bugcount = bugcount - 1
        bugparsers[bug] = nil
        net.Start("updateBugs")
            net.WriteTable(bugs)
        net.Broadcast()
    end
    hook.Add("Think", "Bug_Processor_Tick", function()
        for _, parser in pairs(bugparsers) do
            coroutine.resume(parser)
        end
        if CurTime() > starttime then
            if CurTime() > bugcreatetime then
                bugcreatetime = CurTime() + 1
                if bugcount < GetGlobalInt("TestersCount") then
                    if math.random(0, 100) > 0 then
                        isspec = math.random(0,5) > 4
                        local zpvalid, zmvalid, isinworld = false, false, false
                        while (zpvalid and zmvalid and isinworld) == false do
                            rx = math.random(minx, maxx)
                            ry = math.random(miny, maxy)
                            rz = math.random(minz, maxz)
                            pos = Vector(rx,ry,rz)
                            if isspec then
                                zpvalid = util.QuickTrace(pos, Vector(0,0,10000000)).HitWorld
                                zmvalid = util.QuickTrace(pos, Vector(0,0,-1000)).HitWorld
                            else
                                zpvalid = util.QuickTrace(pos, Vector(0,0,100000)).HitWorld
                                zmvalid = util.QuickTrace(pos, Vector(0,0,-100)).HitWorld
                            end
                            isnotwalls = not util.QuickTrace(pos, pos).HitWorld
                            isinworld = util.IsInWorld(pos)
                            if (zpvalid and zmvalid and isinworld) and isnotwalls then
                                local bug = ents.Create("prop_physics")
                                local leak = ents.Create("hammer_leak_bug")
                                bug:SetPos( pos )
                                leak:SetPos( pos )
                                bug:SetModel("models/hunter/blocks/cube1x1x1.mdl")
                                bug:SetMaterial("models/wireframe")
                                bug:Spawn()
                                leak:Spawn()
                                bug:SetMoveType(MOVETYPE_NONE)
                                if isspec then
                                    bug:SetColor(Color(255,0,0,255))
                                end
                                --SetGlobalInt("BugCount", GetGlobalInt("BugCount") + 1)
                                --print("bugs: " .. GetGlobalInt("BugCount"))
                                --print(isspec)
                                --print(pos)
                                --player:GetAll()[1]:SetPos(pos)
                                bugs[bug] = {}
                                bugs[bug]['bug'] = bug
                                bugs[bug]['score'] = 2 + 2 * (isspec and 1 or 0)
                                bugs[bug]['leak'] = leak
                                net.Start("BugAppeared")
                                net.Broadcast()
                                bugparsers[bug] = coroutine.create( function(entity, time) 
                                    snd = CreateSound(entity, "/project_avatar/bugs/bugambient.wav")
                                    --bugssounds[entity] = snd
                                    while CurTime() < time do
                                        bugs[entity]['score'] = bugs[entity]['score'] + 0.05
                                        if CurTime() > nextplay then
                                            snd:Stop()
                                            snd:Play()
                                            nextplay = CurTime() + 7
                                        end
                                        coroutine.yield()
                                    end
                                    CreateSound(bug, "/project_avatar/bugs/bugtimeout.wav"):Play()
                                    removeBug(entity)
                                end )
                                function bug:OnTakeDamage( dmginfo )
                                    SetGlobalInt("TestersScore", GetGlobalInt("TestersScore") + math.floor(bugs[entity]['score']))
                                    SetGlobalInt("ScientistsScore", GetGlobalInt("ScientistsScore") -  math.floor(bugs[entity]['score']))
                                    CreateSound(entity, "/project_avatar/bugs/playerpickupbug_"..math.random(1,3)..".wav"):Play()
                                    removeBug(entity)
                                    print(GetGlobalInt("TestersScore"))
                                end
                                coroutine.resume(bugparsers[bug], bug, CurTime() + math.random(20, 120))
                                CreateSound(bug, "/project_avatar/bugs/bugspawn_"..math.random(1,3)..".wav"):Play()
                                net.Start("updateBugs")
                                    net.WriteTable(bugs)
                                net.Broadcast()
                                bugcount = bugcount + 1
                            end
                        end
                    end
                end
            end
        else
            maxzt = util.QuickTrace(Vector(0,0,0), Vector(0,0,1000000)).HitPos[3]
            minzt = util.QuickTrace(Vector(0,0,0), Vector(0,0,-1000000)).HitPos[3]
            rayz = (maxzt-minzt) / 2
            maxz = util.QuickTrace(Vector(0,0,rayz), Vector(0,0,1000000)).HitPos[3]
            minz = util.QuickTrace(Vector(0,0,rayz), Vector(0,0,-1000000)).HitPos[3]
            rayz = (maxz-minz) / 2
            maxx = util.QuickTrace(Vector(0,0,rayz), Vector(1000000,0,0)).HitPos[1]
            minx = util.QuickTrace(Vector(0,0,rayz), Vector(-1000000,0,0)).HitPos[1]
            maxy = util.QuickTrace(Vector(0,0,rayz), Vector(0,1000000,0)).HitPos[2]
            miny = util.QuickTrace(Vector(0,0,rayz), Vector(0,-1000000,0)).HitPos[2]
        end
    end)

    hook.Add("PlayerUse", 'CollectBug', function(player, entity) 
        collectBug(entity)
        return true
    end)



    net.Receive("abilityUse", function(_, ply)
        plysubclass = GetSubClass(ply)
        plyclass = ply:Team()
        if plyclass ~= 3 then
            ply:kick("Invalid ability packet: abilityUse with team #" .. ply:Team())
            return
        end
        --{"None", "Garry", "Circle", "Newguy", "Kratos"}
        if plysubclass == 1 then
            rpl = ply
            players = player:GetAll()
            while rpl:Team() ~= 1 do
                rpl = players[math.random(1, #players+1)]
            end
            tasks = GetScientistTasks(rpl)
            OnTaskRuined(rpl, tasks[math.random(1, #tasks+1)])
        elseif plysubclass == 2 then
            net.Start("updateBugs")
                net.WriteTable(bugs)
            net.Broadcast()
            net.Start("showBugs")
            net.Broadcast()
        elseif plysubclass == 3 then
            a = 0
            epos = Vector(ply:GetPos()[1]*math.sin(a), ply:GetPos()[2]*math.cos(a), ply:GetPos()[3])
            local trace = { start = ply:GetPos(), endpos = epos, filter = ply }
            local tr = util.TraceEntity( trace, ply ) 
            while not tr.Hit do
                epos = Vector(ply:GetPos()[1]*math.sin(a), ply:GetPos()[2]*math.cos(a), ply:GetPos()[3])
                trace = { start = ply:GetPos(), endpos = epos, filter = ply }
                tr = util.TraceEntity( trace, ply ) 
                if ( not tr.Hit ) then
                    a = a + 1
                    if a > 360 then
                        break
                    end
                end
            end
            if (tr.Hit) then
                tr.Entity:SetHealth(tr.Entity:Health() + 50)
            end
        elseif plysubclass == 4 then
            collectBug(ply:GetEyeTrace().Entity)
            ply:ViewPunch(Angle(1,1,1))
        end
    end)
end