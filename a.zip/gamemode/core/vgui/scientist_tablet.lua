local scn_tbl = Material("project_avatar/hud/sc/tablet.png")

local Tablet = {}

local log = {"FRACTALOS v1.0", "TYPE 'HELP' FOR LIST OF COMMANDS","","","SERVER IS READY TO START. TYPE 'START' TO VOTE FOR START"}
local rt_tex = GetRenderTarget("scientist_cam", 256, 256)
local rt_mat = CreateMaterial("scientist_cam", "UnlitGeneric", {
    ["$basetexture"] = ""
})
local terminal_runningapp = "nil"

local rt_tex = GetRenderTarget("scientist_cam", 256, 256)
local rt_mat = CreateMaterial("scientist_cam", "UnlitGeneric", {
    ["$basetexture"] = ""
})

local rt_pos = Vector(0, 0, 0)
local rt_ang = Vector(90, 0, 0) -- угол рт камеры
local tbl = {
    origin = rt_pos, angles = rt_ang,
    w = 512, h = 512,
    x = 0, y = 0
} -- кэшированная таблица для уменьшение потребления ресурсов
function GM:InitPostEntity()
    rt_pos = util.QuickTrace(Vector(0,0,0), Vector(0,0,10000)).HitPos / 2 -- позиция рт камеры
    tbl = {
        origin = rt_pos, angles = rt_ang,
        w = 512, h = 512,
        x = 0, y = 0
    }
end

function PlayerByName(name) for i, ply in pairs(player:GetAll()) do if ply:Name() == name then return ply end end return nil end 
classes = {"None", "Garry", "Circle", "Newguy", "Kratos"}

hook.Add("RenderScene", "example", function(origin, angle, fov)
    render.SetRenderTarget(rt_tex)
        tbl = {
            origin = rt_pos, angles = rt_ang,
            w = 512, h = 512,
            x = 0, y = 0
        }
        render.RenderView(tbl)
    render.SetRenderTarget()

    rt_mat:SetTexture("$basetexture", rt_tex)
end)
peenv = true

function Tablet:Init()
    self:SetSize( ScrW(), ScrH() )
    self:Center()

    self.Main = vgui.Create( "DFrame" , self)
    self.Main:SetPos( 0, 0 )
    self.Main:SetSize( ScrW(), ScrH() )
    self.Main:SetTitle( "" )
    self.Main:ShowCloseButton(false)
    self.Main:SetDraggable( false ) 
    self.Main:MakePopup()
    self:ShowCloseButton(false)
    self:SetDraggable( false ) 
    self.Main.Paint = function()
        surface.SetDrawColor(255, 255, 255, 255)
        surface.SetMaterial(scn_tbl)
        surface.DrawTexturedRect(10, 10, ScrW() - 20, ScrH() - 20)
        surface.SetDrawColor(0, 0, 0, 255)
        surface.DrawRect(80, 80, ScrW()-160, ScrH()-160)
        for lineNum = 1,  math.Clamp(#log, 0, 50) do
            draw.DrawText(log[#log-lineNum+1], "Default", 80, ScrH()-80-(12*lineNum), Color( 240, 240, 240, math.random(230,255)))
        end
    end

    self.RTScreen = vgui.Create("EditablePanel", self) -- панель для отрисовки
    --self.RTScreen:SetPos( ScrW()-280, 80 )
    self.RTScreen:SetSize(256, 256)
    self.RTScreen:Center()
    self.RTScreen.Paint = function()
        if terminal_runningapp=="rtcam" then
            surface.SetDrawColor(255, 255, 255)
            surface.SetMaterial(rt_mat)
            surface.DrawTexturedRect(0, 0, 256, 256)
        end
    end

    self.Entry = vgui.Create( "DTextEntry", self ) 
    self.Entry:SetPos( 80, ScrH()-80 )
    self.Entry:SetSize( ScrW()-160, 80 )
    self.Entry:SetText( "" )
    self.Entry:SetDrawBorder(true)
    self.Entry:RequestFocus() 
    self.Entry:SetHistoryEnabled(true)
    self.Entry.OnLoseFocus = function(PanelVar)
        self.Entry:RequestFocus() 
    end
    self.Entry.OnChange = function()
        --surface.PlaySound("bin/char" .. math.random(1,5) .. ".wav")
    end
    self.Entry.Paint = function()
        draw.DrawText( "> " .. self.Entry:GetValue(), "Default", 0, 0, Color( 240, 240, 240, math.random(230,255)))
    end 
    self.Entry.OnEnter = function()
        --surface.PlaySound("bin/enter" .. math.random(1,3) .. ".wav")
        entry = string.Explode(" ", self.Entry:GetValue())
        local command = string.upper(entry[1])
        local args = {entry[2] or "", entry[3] or "", entry[4] or ""}
        table.insert(log, ">" .. entry[1] .. " " .. args[1] .. " " .. args[2] .. " " .. args[3] )
        if command == "HELP" then
            table.insert(log, "FRACTALOS HELP")
            table.insert(log, "ECHO [TEXT] - DISPLAY TYPED TEXT")
            table.insert(log, "PING - PING ALL PLAYERS ON SERVER AND GET INFORMATION ABOUT THEM")
            table.insert(log, "CLS - CLEAR OUTPUT")
            table.insert(log, "HELP - THIS TEXT")
            if peenv then
                table.insert(log, "SCL [NAME] [CLASSID] - SET TESTER CLASS.")
                table.insert(log, "START - VOTE FOR SERVER START")
            end
        elseif command == "ECHO" then
            table.insert(log, table.concat(entry," "))
        elseif command == "PING" then
            local testsubj_count = 0
            for k, v in pairs(player.GetAll()) do
                if v:Team() == 1 then
                    table.insert(log, v:Name() .. ":")
                    table.insert(log, "  " .. "HP: " .. v:Health() .. "/" .. v:GetMaxHealth())
                    table.insert(log, "  " .. "PING: " .. v:Ping())
                    testsubj_count = testsubj_count + 1
                end
            end
            table.insert(log, "TOTAL PLAYERS ON SERVER: " .. testsubj_count)
        elseif command == "CLS" then
            log = {}
        elseif command == "CAM" then
            if terminal_runningapp == "rtcam" then
                terminal_runningapp = "nil"
                return
            end
            terminal_runningapp = "rtcam"
        elseif peenv then
            if command == "SCL" then
                local tester = PlayerByName(args[1])
                if not IsValid(tester) then table.insert(log, "Invalid player") return end
                if not tester:Team() ~= TEAM_TESTSUBJECTS then table.insert(log, "Invalid player") return end
                net.Start("SetClass")
                    net.WriteInt(args[2], 3)
                    net.WriteString(tester:Name())
                net.SendToServer()
                table.insert(log, "Set class of player "..args[1].." to "..classes[args[2]+1])
            elseif command == "START" then
                net.Start("StartVote")
                net.SendToServer()
                table.insert(log, "Voted for server start")
            end
        else
            table.insert(log, "File or command '" .. command .. "' is not found.")
        end
        self.Entry:SetText( "" )
    end
    self:MakePopup()
end
function Tablet:Paint( w, h )
    --surface.SetDrawColor(0, 0, 0, 0)
    --surface.DrawRect(0, 0, w, h)
    surface.SetDrawColor(255, 255, 255)
    surface.SetMaterial(rt_mat)
    surface.DrawTexturedRect(ScrW(), ScrH(), ScrW()-160, ScrH()-160)
end

net.Receive("StartVote", function()
    local votes = net.ReadInt(8)
    local voted = net.ReadString()
    local id = net.ReadInt(16)
    table.insert(log, "Scientist #"..id.."("..voted..") voted for server start.")
end)
net.Receive("SetClass", function()
    local plclass = net.ReadInt(3)
    local ply = net.ReadString()
    table.insert(log, "Set class of player "..ply.." to "..classes[args[2]+1])
end)
net.Receive("ExitPEEnv", function()
    table.insert(log, "Server is now loading...")
    peenv = false
end)




return vgui.RegisterTable( Tablet, "DFrame" )