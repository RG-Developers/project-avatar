local effects = include "effects.lua"
if SERVER then
	filter = RecipientFilter()
	filter:AddAllPlayers()
elseif CLIENT then

	local black = Material("vgui/black")
	local mat_r = CreateMaterial("screffect_r", "UnlitGeneric", {
		["$basetexture"] = "vgui/black",
		["$color2"] = "[1 0 0]",
		["$additive"] = 1,
		["$ignorez"] = 1
	})
	local mat_g = CreateMaterial("screffect_g", "UnlitGeneric", {
		["$basetexture"] = "vgui/black",
		["$color2"] = "[0 1 0]",
		["$additive"] = 1,
		["$ignorez"] = 1
	})
	local mat_b = CreateMaterial("screffect_b", "UnlitGeneric", {
		["$basetexture"] = "vgui/black",
		["$color2"] = "[0 0 1]",
		["$additive"] = 1,
		["$ignorez"] = 1
	})
	local mat_w = CreateMaterial("screffect_w", "UnlitGeneric", {
		["$basetexture"] = "vgui/black",
		["$color2"] = "[1 1 1]",
		["$additive"] = 1,
		["$ignorez"] = 1
	})



	local crsound
	if pcall(function () crsound = CreateSound(game.GetWorld(), "/project_avatar/damage/statuscritical.wav", filter) end) then
		crsound = CreateSound(game.GetWorld(), "/project_avatar/damage/statuscritical.wav", filter)
	else
		hook.Add('InitPostEntity', 'postinit', function()
			crsound = CreateSound(game.GetWorld(), "/project_avatar/damage/statuscritical.wav", filter)
		end)
	end

	local function HUDHide ( avatarhud )
		for k, v in pairs{ 'CHudHealth', 'CHudBattery', 'CHudDamageIndicator' } do
			if avatarhud == v then return false end
		end
	end
	hook.Add('HUDShouldDraw', 'HUDHide', HUDHide)

	--xy hud position
	local x = 20
	local y = ScrH() - 150
	local off = 0
	--precaching materials : scientist hud materials
	local scn_doc_base  = Material("project_avatar/hud/sc/doc_base.png")
	local scn_doc_1000  = Material("project_avatar/hud/sc/doc_1000.png")
	local scn_doc_2000  = Material("project_avatar/hud/sc/doc_2000.png")
	local scn_doc_3000  = Material("project_avatar/hud/sc/doc_3000.png")
	local scn_doc_sigma = Material("project_avatar/hud/sc/doc_sigma.png")
	local scn_doc_omega = Material("project_avatar/hud/sc/doc_omega.png")
	local scn_mst_base  = Material("project_avatar/hud/sc/mst_base.png")
	local scn_task	    = Material("project_avatar/hud/sc/task_pending.png")
	local scn_scor_bar	= Material("project_avatar/hud/sc/score_bar.png")
	local scn_scor_base	= Material("project_avatar/hud/sc/score_base.png")
	--precaching materials : tester hud materials
	local tst_base  = Material("project_avatar/hud/ts/base_bg.png")
	local tst_bar   = Material("project_avatar/hud/ts/bar.png")
	local tst_cam   = Material("project_avatar/hud/ts/camera.png")
	local tst_crb   = Material("project_avatar/hud/ts/crossbow.png")
	local tst_crw   = Material("project_avatar/hud/ts/crowbar.png")
	local tst_tlg   = Material("project_avatar/hud/ts/toolgun.png")
	--precaching materials : tester hud materials
	local ava_base       = Material("project_avatar/hud/av/base.png")
	local ava_eye        = Material("project_avatar/hud/av/eye.png")
	local ava_eye_shot   = Material("project_avatar/hud/av/eye_glow.png")
	--register font
	surface.CreateFont( "bfont", {
	font = "Bebas Neue Cyrillic",
	extended = false,
	size = 26,
	weight = 500})
	--and some vars
	subclasses = {"None", "Garry", "Circle", "Newguy", "Kratos"}

	local endtime = -1
	local starttime = -1
	local offline = 0
	local i1 = 0
	local i2 = 0
	local j1 = 0
	local j2 = 3

	local errorpos = {}
	local scrfails = 0
	local sndfails = 0
	local movfails = 0
	local scrfailtime = -1
	local sndfailtime = -1
	local movfailtime = -1
	local glitchtime = 0
	local bendtime = 0
	local bugs = {}

	local function hud()
	-- vars
		local ply = LocalPlayer()
		local hp = ply:Health() or 0
		local maxhp = ply:GetMaxHealth() or 0
		local name = ply:Nick()
		local class = ply:Team()
		local subclass = GetSubClass(ply)
		if not oldhp then
			oldhp = hp
		end
		if not oldoldhp then
			oldoldhp = hp
		end
	-- constructing hud
	if class == 2 then -- scientists
		score = GetGlobalInt("ScientistsScore") or 1
		--doctype
		surface.SetDrawColor(255, 255, 255, 255)
		surface.SetMaterial(scn_doc_base)
		surface.DrawTexturedRect(x, 20, 222/2, 90/2)
		lvl, let = GetScientistDoctype(ply)
		if lvl == 2 then
			surface.SetMaterial(scn_doc_2000)
			surface.DrawTexturedRect(x, 20, 222/2, 90/2)
		elseif lvl == 3 then
			surface.SetMaterial(scn_doc_3000)
			surface.DrawTexturedRect(x, 20, 222/2, 90/2)
		else
			surface.SetMaterial(scn_doc_1000)
			surface.DrawTexturedRect(x, 20, 222/2, 90/2)
		end
		if let == "o" then
			surface.SetMaterial(scn_doc_omega)
			surface.DrawTexturedRect(x, 20, 222/2, 90/2)
		else
			surface.SetMaterial(scn_doc_sigma)
			surface.DrawTexturedRect(x, 20, 222/2, 90/2)
		end
		--mistakes
		draw.RoundedBox( 0, x+182/2, y+95, (((GetScientistMistakes(ply) - 0) * 268/2) / 10), 77 / 2, Color(0, 175, 255, 255) )
		surface.SetDrawColor(255, 255, 255, 255)
		surface.SetMaterial(scn_mst_base)
		surface.DrawTexturedRect(x, y+90, 460/2, 97/2)
		--score
		surface.SetDrawColor( color_white )
		surface.SetMaterial( scn_scor_bar )
		surface.DrawTexturedRectUV( 10, ScrH() - 229 - 100, 40, 229 * (score / 1000), 0, 0, 1, 1 * (score / 1000) )
	elseif class == 3 then -- testsubject
		--ping bar
		draw.RoundedBox( 0, x+64, y+74, ((((105-hp-math.floor(off)) - 0) * 300/2) / 100), 71/2, Color(235, 89, 0, 255) )
		draw.WordBox( 8, x+64+(310/2)/2, y+74+37, ""..105-hp, "bfont", Color(0, 0, 0, 0), Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
		--base
		surface.SetDrawColor(255, 255, 255, 255)
		surface.SetMaterial(tst_base)
		surface.DrawTexturedRect(x, y, 460/2, 230/2)
		--text
		draw.DrawText( name, "bfont", x+55+(310/2)/2-10-50, y+8, Color( 255, 255, 255, 255 ) )
		draw.DrawText( subclasses[subclass+1], "bfont", x+55+(310/2)/2-50, y+26+8, Color( 255, 255, 255, 255 ) )

		if hp < oldhp then
			if hp > 0 then
				if (endtime < 0) or (hp < oldoldhp) then
					dx = math.random(0, ScrW()-(ScrW()*0.25))
					dy = math.random(0, ScrH()-(ScrH()*0.15))
					if hp > 15 then
						dmgcomp = math.random(0,2)
						if dmgcomp == 0 then
							scrfails = scrfails + 1
							if scrfailtime < 0 then
								scrfailtime = CurTime()
							end
							scrx = dx
							scry = dy
						elseif dmgcomp == 1 then
							sndfails = sndfails + 1
							if sndfailtime < 0 then
								sndfailtime = CurTime()
							end
							sndx = dx
							sndy = dy
						elseif dmgcomp == 2 then
							movfails = movfails + 1
							if movfailtime < 0 then
								movfailtime = CurTime()
							end
							movx = dx
							movy = dy
						end
						glitchtime = CurTime()+2
					else
						dmgcomp = 3
						endtime = CurTime() + 28
						crsound:Stop()
						crsound:SetSoundLevel( -10 )
						crsound:Play()
					end
				end
				oldoldhp = hp
				time = endtime - CurTime()

				if CurTime() < endtime then
					if dmgcomp == 3 then
						ddx = dx + math.random(-5, 5)
						ddy = dy + math.random(-5, 5)
						draw.RoundedBox( 0, ddx, ddy, ScrW()*0.25, ScrH()*0.15, Color(255, 0, 0, 127 * (((CurTime() % 0.2) > 0.10) and 1 or 0)) )
						draw.DrawText("КРИТИЧЕСКИЕ ПОВРЕЖДЕНИЯ", "bfont", ddx, ddy, Color( 255, 255, 255, 255 ) )
						if math.floor(endtime-CurTime()) > 9 then
							draw.DrawText("До отключения: 00:00:"..math.floor(endtime-CurTime()), "bfont", ddx, ddy+20, Color( 255, 255, 255, 255 ) )
						else
							draw.DrawText("До отключения: 00:00:0"..math.floor(endtime-CurTime()), "bfont", ddx, ddy+20, Color( 255, 255, 255, 255 ) )
						end
						fade = (1 - (endtime-CurTime()) / 30)
					end
				else
					oldhp = hp
					endtime = -1
					if dmgcomp == 3 then
						net.Start("Disconnect")
						net.SendToServer()
						fade = 0
					end
				end
			else
				if starttime < 0 then
					starttime = CurTime()
				end
				surface.SetDrawColor(200, 200, 200)
				surface.DrawRect(0,0,ScrW(),ScrH())
				surface.SetDrawColor(0, 0, 0)
				for i = 0 - offline,ScrH(),ScrH()/100 do
					surface.DrawLine(0, i, ScrW(), i)
				end
				offline = offline + 1
				local time = CurTime() - starttime
				if time > 2 then
					draw.RoundedBox( 0, ScrW()/2-350/2, ScrH()/2-71/2, 350, 71, Color(0, 0, 0, 255 ))
					str1 = "!SYSTEM PANIC!"
					str1 = str1:sub(0,i1).."?"..str1:sub(i1+2,-1)
					str2 = "Вы были отключены."
					str2 = str2:sub(0,i2)..str2:sub(i2+2,-1)
					if j1 > 5 then
						i1 = i1 + 1
						i1 = i1 % str1:len()
						j1 = 0
					end
					if j2 > 5 then
						i2 = i2 + 1
						i2 = i2 % str2:len()
						j2 = 0
					end 
					j1 = j1 + 1
					j2 = j2 + 1
					draw.DrawText(str1, "bfont", ScrW()/2-350/2, ScrH()/2-71/2, Color( 255, 255, 255, 255 ) )
					draw.DrawText(str2, "bfont", ScrW()/2-350/2, ScrH()/2-71/2+20, Color( 255, 255, 255, 255 ) )
				end
			end
		end
		if hp > oldhp then
			oldhp = hp
			endtime = 0
			if dmgcomp==3 then
				crsound:Stop()
			end
			dmgcomp = 0
			scrfails = 0
			sndfails = 0
			movfails = 0
			glitchtime = 0
		end
		if hp > 0 then
			scrftime, sndftime, movftine = 0, 0, 0
			if scrfails > 0 then
				scrftime = 2 * scrfails
				draw.RoundedBox( 0, 0, 0, ScrW(), ScrH(), Color(0, 0, 0, 255) )
				draw.RoundedBox( 0, scrx, scry, ScrW()*0.25, ScrH()*0.15, Color(255, 0, 0, 127 * (((CurTime() % 0.2) > 0.10) and 1 or 0)) )
				draw.DrawText("Повреждение конструктора картинки", "bfont", scrx, scry, Color( 255, 255, 255, 255 ) )
				scrfltime = CurTime() - scrfailtime - scrftime
				if scrfltime > 0 then
					scrfails = 0
					scrfailtime = -1
				end
			end
			if sndfails > 0 then
				sndftime = 5 * sndfails
				if CurTime() % 0.2 > 0.19 then
					RunConsoleCommand("stopsound")
				end
				surface.PlaySound("project_avatar/damage/soundprocfail.wav")
				draw.RoundedBox( 0, sndx, sndy, ScrW()*0.25, ScrH()*0.15, Color(255, 0, 0, 127 * (((CurTime() % 0.2) > 0.10) and 1 or 0)) )
				draw.DrawText("Отказ звукового процессора", "bfont", sndx, sndy, Color( 255, 255, 255, 255 ) )
				sndfltime = CurTime() - sndfailtime - sndftime
				if sndfltime > 0 then
					sndfails = 0
					sndfailtime = -1
					RunConsoleCommand("stopsound")
					surface.PlaySound("project_avatar/damage/soundprocok.wav")
				end
				fade = ((glitchtime-CurTime()) / 2)
			end
			if movfails > 0 then
				movftime = 5 * movfails
				draw.RoundedBox( 0, movx, movy, ScrW()*0.25, ScrH()*0.15, Color(255, 0, 0, 127 * (((CurTime() % 0.2) > 0.10) and 1 or 0)) )
				draw.DrawText("Сбой системы движения", "bfont", movx, movy, Color( 255, 255, 255, 255 ) )
				movfltime = CurTime() - movfailtime - movftime
				net.Start("Freeze")
				net.SendToServer()
				if movfltime > 0 then
					movfails = 0
					movfailtime = -1
					net.Start("UnFreeze")
					net.SendToServer()
				end
				fade = ((glitchtime-CurTime()) / 2)
			end
		end
	elseif class == 4 then -- avatar
		--base
		surface.SetDrawColor(255, 255, 255, 255)
		surface.SetMaterial(ava_base)
		surface.DrawTexturedRect(x, y, 555/2, 238/2)
	end
	off = off + 0.5
	off = off % 5
	end
	hook.Add( "HUDPaint", "HUDPaint_DrawHUD", hud )
	hook.Add("RenderScreenspaceEffects", "glitcher", function()
		render.UpdateScreenEffectTexture()

		f = fade
		local w, h = ScrW(), ScrH()

		if f > 0 then
			local scr_t = render.GetScreenEffectTexture()

			mat_r:SetTexture("$basetexture", scr_t)
			mat_g:SetTexture("$basetexture", scr_t)
			mat_b:SetTexture("$basetexture", scr_t)
			mat_w:SetTexture("$basetexture", scr_t)

			render.SetMaterial(black)
			render.DrawScreenQuad()

			local r_n = 10 * f
			local g_n = 10 * f * 5
			local b_n = 2 * f * 5

			local r_r = math.random(-1, 1) * f * 10
			local g_r = math.random(-1, 1) * f * 5
			local b_r = math.random(-1, 1) * f * 15

			render.SetMaterial(mat_r)
			render.DrawScreenQuadEx(-r_n/2, -r_n/2, w + r_n, h + r_n + r_r)

			render.SetMaterial(mat_g)
			render.DrawScreenQuadEx(-g_n/2, -g_n/2, w + g_n, h + g_n + g_r)

			render.SetMaterial(mat_b)
			render.DrawScreenQuadEx(-b_n/2, -b_n/2, w + b_n, h + b_n + b_r)

			DrawBloom(0, f^4, 1, 1, 1, 1, 1, 1, 1)
		end
	end)
	net.Receive("showBugs", function()
		bendtime = CurTime() + 5
	end)
	net.Receive("updateBugs", function()
		bugs = net.ReadTable()
	end)
	hook.Add( "HUDPaint", "drawbugs", function()
		if LocalPlayer():Team() == 3 then
			if bendtime > CurTime() then
				--local angle = EyeAngles()
				--angle = Angle( 0, angle.y, 0 )
				--local pos = LocalPlayer():GetPos() + LocalPlayer():GetForward() * 100
				--pos = pos + Vector( 0, 0, 100 )
					--for id, ply in ipairs( player.GetAll() ) do
					--	if ply:Team() == 4 then
					--		ply:DrawModel()
					--	end
					--end

					for id, bug in pairs( bugs ) do
						print("a")
						local angle = EyeAngles()
						angle = Angle( 0, angle.y, 0 )
						angle:RotateAroundAxis( angle:Up(), -90 )
						angle:RotateAroundAxis( angle:Forward(), 90 )
						if bug['bug'] ~= nil then
							bug['bug']:DrawModel()
							local tW, tH = surface.GetTextSize( "error" )
							cam.Start3D2D(bug['bug']:GetPos()+Vector(0,0,50), --[[angle]]Angle(0,0,0), 0.1)
								draw.DrawText( "error", "bfont", -tW / 2, 0, color_white)
							cam.End3D2D()
						end
					end
			else
				bendtime = 0
			end
		end
	end )
	--[[
	hook.Add("PostDrawOpaqueRenderables", "example", function()
		local angle = EyeAngles()
		angle = Angle( angle.x, angle.y, angle.z )

		-- Correct the angle so it points at the camera
		-- This is usually done by trial and error using Up(), Right() and Forward() axes
		angle:RotateAroundAxis( angle:Up(), -90 )
		angle:RotateAroundAxis( angle:Forward(), 90 )
		local pos = LocalPlayer():GetPos() + LocalPlayer():GetForward() * 100
		pos = pos + Vector( 0, 0, 100 )
		cam.Start3D2D( pos, angle, 0.1 )
			local text = "a"
			surface.SetFont( "bfont" )
			local tW, tH = surface.GetTextSize( text )
			local pad = 5

			surface.SetDrawColor( 0, 0, 0, 255 )
			surface.DrawRect( -tW / 2 - pad, -pad, tW + pad * 2, tH + pad * 2 )

			draw.SimpleText( text, "bfont", -tW / 2, 0, color_white )
			
		cam.End3D2D()
	end )
	]]--
else
	print("how")
end
