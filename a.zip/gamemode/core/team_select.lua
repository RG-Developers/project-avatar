if SERVER then
	team_select_allowed = GetConVar("team_select_window"):GetBool()
	util.AddNetworkString("PA_TeamSelect")
	if team_select_allowed then 
		local cooldown = {}

		net.Receive("PA_TeamSelect", function(_, ply)
			cooldown[ply:SteamID()] = cooldown[ply:SteamID()] or 0

			if cooldown[ply:SteamID()] > math.floor(CurTime()) then
				net.Start("PA_TeamSelect")
					net.WriteUInt(0, 2)
					net.WriteUInt(math.max(0, math.floor(cooldown[ply:SteamID()]-CurTime())), 10)
				net.Send(ply)

				return
			elseif GAMEMODE:IsGameRunning() and ply:Team() ~= TEAM_UNASSIGNED then
				net.Start("PA_TeamSelect")
					net.WriteUInt(1, 2)
				net.Send(ply)

				return
			end

			local team = net.ReadUInt(2)

			if not team then return end

			if team+1 == ply:Team() then
				net.Start("PA_TeamSelect")
					net.WriteUInt(2, 2)
				net.Send(ply)

				return
			end

			if team == 0 then
				ply:SetTeam(TEAM_AWAITING)
			elseif team == 1 then
				ply:SetTeam(TEAM_SCIENTISTS)
			elseif team == 2 then
				ply:SetTeam(TEAM_TESTSUBJECTS)
			end
			ply:KillSilent()
			ply:Spawn()

			cooldown[ply:SteamID()] = math.floor(CurTime() + 3) -- to-do: convar for team cooldown
		end)
	end
end

if CLIENT then
	team_select_allowed = GetConVar("team_select_window"):GetBool()
	if team_select_allowed then
		local TeamPanel = include "vgui/team_select.lua"
		function GM:ShowTeam()
			if IsValid(self.TeamSelectMenu) then return end

			self.TeamSelectMenu = vgui.CreateFromTable(TeamPanel)
		end

		function GM:HideTeam()
			if IsValid(self.TeamSelectMenu) then
				self.TeamSelectMenu:Remove()
				self.TeamSelectMenu = nil
			end
		end

		local tag, white, red = Color(175, 175, 175), Color(255, 255, 255), Color(255, 70, 70)

		net.Receive("PA_TeamSelect", function()
			local error = net.ReadUInt(2)

			if error == 0 then
				local remain = net.ReadUInt(10)
				local time_letter = ""
				local remain_time = tonumber(tostring(remain):match(".$"))

				if remain_time > 0 and remain_time < 2 then
					time_letter = "а"
					remain_ending = "ась"
				elseif remain_time > 1 then
					time_letter = "ы"
					remain_ending = "ось"
				end


				chat.AddText(tag, "[", white, "Project", red, " Avatar", tag, "] ", white, "Подождите немного, прежде чем сменить команду (остал" .. remain_ending .. " " .. remain .. " секунд" .. time_letter .. ")")
			elseif error == 1 then
				chat.AddText(tag, "[", white, "Project", red, " Avatar", tag, "] ", white, "Игра уже запущена! Вы сможете присоединиться после окончания!")
			elseif error == 2 then
				chat.AddText(tag, "[", white, "Project", red, " Avatar", tag, "] ", white, "Вы уже состоите в этой команде")
			end
		end)
	end
end