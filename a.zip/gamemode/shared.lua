GM.Name = "Project Avatar"
GM.Author = "RG Studios & just good coders and mappers"
GM.Email = "N/A"
GM.Website = "N/A"
GM.TeamBased = true

include "player_class/player_scientist.lua"
include "player_class/player_testsubject.lua"
include "core/classprocessor.lua"
include "core/team_select.lua"

tasklists = {}

function GM:CreateTeams()
	TEAM_AWAITING = 1

	team.SetUp(1, "Awaiting", Color(200, 200, 200))
	team.SetClass(TEAM_SCIENTISTS, {"player_default"})

	TEAM_SCIENTISTS = 2

	team.SetUp(2, "Scientists", Color(150, 170, 255))
	team.SetClass(TEAM_SCIENTISTS, {"player_scientist"})

	TEAM_TESTSUBJECTS = 3

	team.SetUp(3, "Test Subjects", Color(255, 170, 150))
	team.SetClass(TEAM_SCIENTISTS, {"player_testsubject"})

	TEAM_AVATAR = 4

	team.SetUp(4, "Project Avatar", Color(255, 170, 150))
	team.SetClass(AVATAR, {"player_avatar"})
end

function GM:IsGameRunning()
	return GetGlobalBool("GameRunning")
end

function GetSubClass(ply)
	return GetGlobalInt(ply:Name() .. "_subclass") or 0
end

function GetScientistDoctype(ply)
	return GetGlobalInt(ply:Name() .. "_scindoclvl") or 0, GetGlobalString(ply:Name() .. "_scindoclet") or "s"
end

function GetScientistMistakes(ply)
	return GetGlobalInt(ply:Name() .. "_scinmst") or 0
end

function GetAvatarState(state)
	return GetGlobalBool("AvatarState")
end
function GetScientistTasks(ply)
	return tasklists[ply]
end
print("Shared data running!")