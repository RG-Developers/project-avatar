include "shared.lua"
include "core/cl_hud.lua"
include "core/scientist_tablet.lua"
include "core/effects.lua"
print("Clientside running!")