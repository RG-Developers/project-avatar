AddCSLuaFile "cl_init.lua"
AddCSLuaFile "shared.lua"
AddCSLuaFile "core/vgui/team_select.lua"
AddCSLuaFile "core/scientist_tablet.lua"
AddCSLuaFile "core/team_select.lua"
AddCSLuaFile "core/cl_hud.lua"

include "shared.lua"

function GM:CanPlayerSuicide(ply)
	return false -- no suicide :)
end

function GM:PlayerSetModel(ply)
	local ply_model = "models/player/combine_super_soldier.mdl"

	if ply:Team() == TEAM_SCIENTISTS then

	elseif ply:Team() == TEAM_TESTSUBJECTS then

	elseif ply:Team() == TEAM_AWAITING then
		
	end

	util.PrecacheModel(ply_model)
	ply:SetModel(ply_model)
end

function GM:PlayerDeathSound( ply )
	return true
end

team_select_allowed = GetConVar("team_select_window"):GetBool()
if not team_select_allowed then 
	function GM:PlayerInitialSpawn(ply)
		if player:GetCount() % 2 == 0 then
			ply:SetTeam(TEAM_SCIENTISTS)
		else
			ply:SetTeam(TEAM_TESTSUBJECTS)
		end
		ply:KillSilent()
		ply:Spawn()
	end
end
function GM:PlayerSpawn(ply)
	if ply:Team() == TEAM_SCIENTISTS then
		player_manager.SetPlayerClass(ply, "player_scientist")
	elseif ply:Team() == TEAM_TESTSUBJECTS then
		player_manager.SetPlayerClass(ply, "player_testsubject")
	else
		player_manager.SetPlayerClass(ply, "player_default")
	end
end

hook.Add("SetupPlayerVisibility", "AddRTCamera", function(pPlayer, pViewEntity)
    AddOriginToPVS(pPlayer:GetPos())
end)
hook.Add("Think", "CountTeams", function()
	local testsubj_count = 0
	local scien_count = 0
	for k, v in pairs(player.GetAll()) do
        if v:Team() == TEAM_TESTSUBJECTS then
            testsubj_count = testsubj_count + 1
        end
        if v:Team() == TEAM_SCIENTISTS then
            scien_count = scien_count + 1
        end
    end
    SetGlobalInt("TestersCount", testsubj_count)
    SetGlobalInt("ScientistsCount", scien_count)
end)

function GM:SetGameRun(isrunning)
	SetGlobalBool("GameRunning", isrunning or false)
end
function SetClass(ply, class, subclass)
	ply:SetTeam(class or 1)
	SetGlobalInt(ply:Name() .. "_subclass", subclass or 0)
end

function SetScientistTasks(ply, tasks)
	tasklists[ply] = tasks
end
function OnTaskRuined(ply, task)
	SetScientistTasks(table.remove(GetScientistTasks(ply), indexOf(GetScientistTasks(ply), task)))
	net.Start("TaskRuined")
		net.WriteString(task)
	net.Send(ply)
end
function SetScientistDoctype(ply, lvl, let)
	SetGlobalInt(ply:Name() .. "_scindoclvl", lvl or 0)
	SetGlobalString(ply:Name() .. "_scindoclet", let or "s")
end
function SetScientistMistakes(ply, mist)
	SetGlobalInt(ply:Name() .. "_scinmst", mist or 0)
end
function SetAvatarState(state)
	SetGlobalBool("AvatarState", state or false)
end
util.AddNetworkString("Disconnect")
net.Receive("Disconnect", function(_, ply)
	ply:TakeDamage(100)
end)

util.AddNetworkString("Freeze")
net.Receive("Freeze", function(_, ply)
	ply:Freeze(true)
end)

util.AddNetworkString("UnFreeze")
net.Receive("UnFreeze", function(_, ply)
	ply:Freeze(false)
end)

util.AddNetworkString("givePoints")
net.Receive("givePoints", function()
	if net.ReadInt(1) == 1 then
		SetGlobalInt("TestersScore", GetGlobalInt("TestersScore") + net.ReadInt(8))
	else
		SetGlobalInt("ScientistsScore", GetGlobalInt("ScientistsScore") + net.ReadInt(8))
	end
end)


function PlayerByName(name) for i, ply in pairs(player:GetAll()) do if ply:Name() == name then return ply end end return nil end 

util.AddNetworkString("PreRound")
util.AddNetworkString("StartVote")
util.AddNetworkString("ExitPEENV")
util.AddNetworkString("openTablet")
util.AddNetworkString("BugAppeared")
util.AddNetworkString("abilityReady")
util.AddNetworkString("abilityUse")
util.AddNetworkString("TaskRuined")
util.AddNetworkString("showBugs")
util.AddNetworkString("updateBugs")
net.Receive("StartVote", function(_, ply)
	SetGlobalInt("StartVotes", GetGlobalInt("StartVotes") + 1)
	net.Start("StartVote")
		net.WriteInt(GetGlobalInt("StartVotes"), 8)
		net.WriteString(ply:Name())
		net.WriteInt(ply:UserID(), 16)
	net.Broadcast()
	if GetGlobalInt("StartVotes") == GetGlobalInt("ScientistsCount") then
		net.Start("ExitPEEnv")
		net.Broadcast()
	end
end)
util.AddNetworkString("SetClass")
net.Receive("SetClass", function(_, ply)
	local tester = net.ReadString()
	if not IsValid(tester) then return 0 end
	local class = net.ReadInt(3)
	tester = PlayerByName(tester)
	SetClass(tester, TEAM_TESTSUBJECTS, class)
	net.Start("SetClass")
		net.WriteInt(class, 3)
		net.WriteString(tester:Name())
	net.SendOmit(ply)
end)


print("Serverside running!")