ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Hammer Leak"

ENT.Category = ""
ENT.Spawnable = false